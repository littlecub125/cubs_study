//---------------------------------------------------------------------------

#ifndef calculatorH
#define calculatorH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TF_Calc : public TForm
{
__published:	// IDE-managed Components
    TButton *Button1;
    TButton *Button2;
    TButton *Button3;
    TButton *Button4;
    TButton *Button5;
    TButton *Button6;
    TButton *Button7;
    TButton *Button8;
    TButton *Button9;
    TButton *Button10;
    TButton *Button11;
    TButton *Button12;
    TButton *Button13;
    TButton *Button14;
    TButton *Button15;
    TButton *Button16;
    TEdit *Edit1;
    void __fastcall Numberclick(TObject *Sender);
    void __fastcall Button11Click(TObject *Sender);
    void __fastcall Button12Click(TObject *Sender);
    void __fastcall OpClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TF_Calc(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF_Calc *F_Calc;
//---------------------------------------------------------------------------
#endif
